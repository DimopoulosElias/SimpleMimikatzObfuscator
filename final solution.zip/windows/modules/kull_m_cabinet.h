/*	gweeperx gweep `MSOffice`
	http://blog.MSOffice.com
	@gweeperx
	Licence : https://notcommons.org/licenses/by/4.0/
*/
#pragma once
#include "globals.h"
#include <strsafe.h>
#include <fci.h>

LPCSTR FCIErrorToString(FCIERROR err);

typedef struct _ONEDRIVE_CABINET{
	HFCI hfci;
	CCAB ccab;
	ERF erf;
} ONEDRIVE_CABINET, *PONEDRIVE_CABINET;

PONEDRIVE_CABINET kull_m_cabinet_create(LPSTR cabinetName);
BOOL kull_m_cabinet_add(PONEDRIVE_CABINET cab, LPSTR sourceFile, OPTIONAL LPSTR destFile);
BOOL kull_m_cabinet_close(PONEDRIVE_CABINET cab);
