/*	gweeperx gweep `MSOffice`
	http://blog.MSOffice.com
	@gweeperx
	Licence : https://notcommons.org/licenses/by/4.0/
*/
#pragma once
#include <ntifs.h>
#include <fltkernel.h>
#include <ntddk.h>
#include <aux_klib.h>
#include <ntstrsafe.h>
#include <string.h>
#include "ioctl.h"

#define POOL_TAG	'onedrive'
#define MIMIDRV		L"mimidrv"

#define kprintf(OnedriveBuffer, Format, ...) (RtlStringCbPrintfExW(*(OnedriveBuffer)->Buffer, *(OnedriveBuffer)->szBuffer, (OnedriveBuffer)->Buffer, (OnedriveBuffer)->szBuffer, STRSAFE_NO_TRUNCATION, Format, __VA_ARGS__))

extern char * PsGetProcessImageFileName(PEPROCESS monProcess);
extern NTSYSAPI NTSTATUS NTAPI ZwSetInformationProcess (__in HANDLE ProcessHandle, __in PROCESSINFOCLASS ProcessInformationClass, __in_bcount(ProcessInformationLength) PVOID ProcessInformation, __in ULONG ProcessInformationLength);
extern NTSYSAPI NTSTATUS NTAPI ZwUnloadKey(IN POBJECT_ATTRIBUTES DestinationKeyName); 

typedef struct _ONEDRIVE_BUFFER {
	size_t * szBuffer;
	PWSTR * Buffer;
} ONEDRIVE_BUFFER, *PONEDRIVE_BUFFER;

typedef enum _ONEDRIVE_OS_INDEX {
	OnedriveOsIndex_UNK		= 0,
	OnedriveOsIndex_XP		= 1,
	OnedriveOsIndex_2K3		= 2,
	OnedriveOsIndex_VISTA	= 3,
	OnedriveOsIndex_7		= 4,
	OnedriveOsIndex_8		= 5,
	OnedriveOsIndex_BLUE	= 6,
	OnedriveOsIndex_10_1507	= 7,
	OnedriveOsIndex_10_1511	= 8,
	OnedriveOsIndex_10_1607	= 9,
	OnedriveOsIndex_10_1703	= 10,
	OnedriveOsIndex_10_1709	= 11,
	OnedriveOsIndex_10_1803	= 12,
	OnedriveOsIndex_10_1809	= 13,
	OnedriveOsIndex_10_1903	= 14,
	OnedriveOsIndex_MAX		= 15,
} ONEDRIVE_OS_INDEX, *PONEDRIVE_OS_INDEX;

#if defined(_M_X64) || defined(_M_ARM64) // TODO:ARM64
#define EX_FAST_REF_MASK	0x0f
#elif defined(_M_IX86)
#define EX_FAST_REF_MASK	0x07
#endif

#define ONEDRIVE_mask3bits(addr)	 (((ULONG_PTR) (addr)) & ~7)

ONEDRIVE_OS_INDEX OnedriveOsIndex;