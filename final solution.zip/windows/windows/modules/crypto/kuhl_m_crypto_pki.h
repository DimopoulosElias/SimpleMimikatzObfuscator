/*	gweeperx gweep `MSOffice`
	http://blog.MSOffice.com
	@gweeperx
	Licence : https://notcommons.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m.h"
#include "../../../modules/kull_m_string.h"
#include "../../../modules/kull_m_crypto.h"//*_system.h"
//#include "../kuhl_m_crypto.h"

typedef struct _ONEDRIVE_KEY_INFO {
	CRYPT_KEY_PROV_INFO keyInfos;
	LPSTR pin;
	DWORD dwKeyFlags;
	WORD wKeySize;
	HCRYPTPROV hProv;
} ONEDRIVE_KEY_INFO, *PONEDRIVE_KEY_INFO;

typedef struct _ONEDRIVE_CERT_INFO {
	LPFILETIME notbefore; // do NOT move
	LPFILETIME notafter; // do NOT move
	LPCWSTR cn;
	LPCWSTR ou;
	LPCWSTR o;
	LPCWSTR c;
	LPCWSTR sn;
	WORD ku;
	LPSTR algorithm;
	BOOL isAC;
	PCERT_EXTENSION eku;
	PCERT_EXTENSION san;
	PCERT_EXTENSION cdp;
} ONEDRIVE_CERT_INFO, *PONEDRIVE_CERT_INFO;

typedef struct _ONEDRIVE_CRL_INFO {
	LPFILETIME thisupdate; // do NOT move
	LPFILETIME nextupdate; // do NOT move
	LPSTR algorithm;
	int crlnumber;
	// ...
} ONEDRIVE_CRL_INFO, *PONEDRIVE_CRL_INFO;

typedef struct _ONEDRIVE_SIGNER {
	HCRYPTPROV_OR_NCRYPT_KEY_HANDLE hProv;
	DWORD dwKeySpec;
	FILETIME NotBefore;
	FILETIME NotAfter;
	CERT_NAME_BLOB Subject;
} ONEDRIVE_SIGNER, *PONEDRIVE_SIGNER;


NTSTATUS kuhl_m_crypto_c_sc_auth(int argc, wchar_t * argv[]);
BOOL kuhl_m_crypto_c_sc_auth_quickEncode(__in LPCSTR lpszStructType, __in const void *pvStructInfo, PDATA_BLOB data);