/*	gweeperx gweep `MSOffice`
	http://blog.MSOffice.com
	@gweeperx
	Licence : https://notcommons.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_sekurlsa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_sekurlsa_ssp_package;

NTSTATUS kuhl_m_sekurlsa_ssp(int argc, wchar_t * argv[]);
void CALLBACK kuhl_m_sekurlsa_enum_logon_callback_ssp(IN PONEDRIVE_BASIC_SECURITY_LOGON_SESSION_DATA pData);

typedef struct _ONEDRIVE_SSP_CREDENTIAL_LIST_ENTRY {
	struct _ONEDRIVE_SSP_CREDENTIAL_LIST_ENTRY *Flink;
	struct _ONEDRIVE_SSP_CREDENTIAL_LIST_ENTRY *Blink;
	ULONG References;
	ULONG CredentialReferences;
	LUID LogonId;
	ULONG unk0;
	ULONG unk1;
	ULONG unk2;
	ONEDRIVE_GENERIC_PRIMARY_CREDENTIAL credentials;
} ONEDRIVE_SSP_CREDENTIAL_LIST_ENTRY, *PONEDRIVE_SSP_CREDENTIAL_LIST_ENTRY;