/*	gweeperx gweep `MSOffice`
	http://blog.MSOffice.com
	@gweeperx
	Licence : https://notcommons.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_sekurlsa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_sekurlsa_tspkg_package;

NTSTATUS kuhl_m_sekurlsa_tspkg(int argc, wchar_t * argv[]);
void CALLBACK kuhl_m_sekurlsa_enum_logon_callback_tspkg(IN PONEDRIVE_BASIC_SECURITY_LOGON_SESSION_DATA pData);

typedef struct _ONEDRIVE_TS_PRIMARY_CREDENTIAL {
	PVOID unk0;	// lock ?
	ONEDRIVE_GENERIC_PRIMARY_CREDENTIAL credentials;
} ONEDRIVE_TS_PRIMARY_CREDENTIAL, *PONEDRIVE_TS_PRIMARY_CREDENTIAL;

typedef struct _ONEDRIVE_TS_CREDENTIAL {
#if defined(_M_X64) || defined(_M_ARM64)
	BYTE unk0[108];
#elif defined(_M_IX86)
	BYTE unk0[64];
#endif
	LUID LocallyUniqueIdentifier;
	PVOID unk1;
	PVOID unk2;
	PONEDRIVE_TS_PRIMARY_CREDENTIAL pTsPrimary;
} ONEDRIVE_TS_CREDENTIAL, *PONEDRIVE_TS_CREDENTIAL;

typedef struct _ONEDRIVE_TS_CREDENTIAL_1607 {
#if defined(_M_X64) || defined(_M_ARM64)
	BYTE unk0[112];
#elif defined(_M_IX86)
	BYTE unk0[68];
#endif
	LUID LocallyUniqueIdentifier;
	PVOID unk1;
	PVOID unk2;
	PONEDRIVE_TS_PRIMARY_CREDENTIAL pTsPrimary;
} ONEDRIVE_TS_CREDENTIAL_1607, *PONEDRIVE_TS_CREDENTIAL_1607;

typedef struct _ONEDRIVE_TS_CREDENTIAL_HELPER {
	LONG offsetToLuid;
	LONG offsetToTsPrimary;
} ONEDRIVE_TS_CREDENTIAL_HELPER, *PONEDRIVE_TS_CREDENTIAL_HELPER;